# Differentiation Protocol

Reference for earned secret extraction, spiky POV development, and clarity-under-pressure drills. Differentiation is scored as the 5th dimension (see SKILL.md rubric).

## When Differentiation Coaching Fires

This protocol activates automatically when:
- Differentiation score < 3 on any answer during analyze
- Candidate's answers could be swapped with another qualified candidate's
- Answer relies on frameworks, buzzwords, or textbook structures without personal insight
- Story lacks an earned secret
- During stories: every story should have an earned secret extracted before it's considered "complete"

---

## Earned Secrets

An earned secret is:
- An insight learned from direct experience that isn't obvious
- Something most people in the field get wrong or don't notice
- Backed by a specific story, metric, or pattern observed
- Defensible if challenged

### NOT Earned Secrets
- Generic advice: "Communication is important"
- Book wisdom: "Psychological safety matters"
- Obvious observations: "Users want fast products"
- Predictions about the future without evidence
- Borrowed insights from podcasts or articles

### How to Extract Earned Secrets

Review the candidate's storybank and transcripts. For each major experience, ask:

1. "What did you believe before that turned out to be wrong?"
2. "What would surprise people who haven't done this?"
3. "What do most people in your field get wrong about this?"
4. "What counterintuitive lesson did you learn?"
5. "What would you tell your past self?"

### Format for Earned Secrets

**Earned Secret**: [2-sentence point of view]

**Proof**: [Metric, artifact, or counterexample from experience]

**When to Deploy**: [Which interview questions this addresses]

### Example Earned Secrets

**PM Example**:
> **Earned Secret**: Most teams over-index on building features and under-invest in instrumentation, which makes every subsequent decision slower and less confident.
>
> **Proof**: At [Company], we spent 2 sprints building analytics before new features. Every PM resisted. Six months later, our ship velocity was 40% faster than peer teams because we weren't debating with opinions—we had data.
>
> **When to Deploy**: Questions about prioritization, technical debt, team velocity, data-driven decisions

**Engineer Example**:
> **Earned Secret**: The best code reviews happen before any code is written. Design docs with clear alternatives prevent 80% of the "let's rewrite this" conversations.
>
> **Proof**: After introducing mandatory design docs, our PR rejection rate dropped from 30% to 8%, and time-to-merge decreased by 40%.
>
> **When to Deploy**: Questions about collaboration, code quality, technical leadership

---

## Spiky POV Polish

Safe answers are forgettable. Spiky answers make interviewers lean in.

### Anatomy of a Spiky Answer
1. **Spiky take**: A principled stance some would disagree with
2. **Surprising lesson**: Not the obvious takeaway
3. **Quantified impact**: With range or caveat if needed

### Transformation Process

Take a safe answer and rewrite with all three elements.

**Safe**: "I believe in user research and gathering feedback before building."

**Spiky**: "Most teams do user research too late—after they've committed to a direction. We ran concept testing before writing any code, which felt inefficient to engineering but saved us from building the wrong thing. The surprising part? Our best insights came from users who said they wanted Feature X but actually needed Feature Y. We shipped Y, got 30% adoption in two months, and later found out Feature X would've solved a problem only 5% of users had. The lesson: Users are great at expressing pain but terrible at prescribing solutions."

### What Makes a Take "Spiky"

Not spiky (universal agreement):
- "Collaboration is important"
- "We should ship fast"
- "Data should inform decisions"

Spiky (reasonable people disagree):
- "Most collaboration slows teams down—async-first is better"
- "Shipping fast is overrated; shipping right matters more"
- "Too much data creates analysis paralysis; start with intuition"

### Guardrails

- The spiky take must be defensible with evidence
- Don't manufacture controversy—find genuine beliefs
- Stay authentic; don't adopt a take you can't back up
- Know when to deploy: spiky answers are memorable but risky if they clash with company culture

---

## Clarity Under Pressure

Preparation gets 80%. The final 20% is thinking clearly when the unexpected happens.

### Interruption Handling Drill

**Setup**: Candidate starts answering a question. Halfway through, interrupt with:

**Skeptical challenge**: "But I'm not convinced by that approach because [reason]"
- Tests: Can they engage with criticism without getting defensive?

**Clarifying question**: "Wait, can you define what you mean by [term they used]?"
- Tests: Do they actually understand their own jargon?

**Pivot**: "Actually, let me stop you. I want to know about [different angle]"
- Tests: Can they switch gears without losing composure?

**Scoring**:
- Recovery grace (defensive vs. curious): 1-5
- Adaptation (addressed the point vs. deflected): 1-5
- Coherence (maintained thread vs. lost it): 1-5

### Constraint Ladder Drill

Practice the same story at multiple time constraints:

1. **30 seconds**: Walking to the interview room
2. **60 seconds**: Executive attention span
3. **90 seconds**: Standard interview answer
4. **3 minutes**: "Tell me more"

For each level, identify:
- What to emphasize vs. cut
- Where to plant hooks for follow-ups
- How to end cleanly if interrupted

Then test: "You're at the 90-second mark, and I interrupt with: 'Can you give me specific numbers on impact?' How do you adapt?"

### Real-Time Thinking Indicators

**Strong signals**:
- Acknowledges the challenge: "That's a fair pushback..."
- Thinks out loud: "Let me think about that for a second..."
- Asks clarifying question: "When you say X, do you mean...?"
- Admits uncertainty: "I'm not 100% sure, but my hypothesis is..."

**Weak signals**:
- Ignores the challenge and continues planned answer
- Gets defensive: "Well, actually..."
- Restarts from the beginning instead of adapting
- Fills silence with filler words instead of thinking

---

## Differentiation in Non-Interview Contexts

Earned secrets and spiky POVs aren't just for interview answers — they power every candidate-facing surface. The same differentiation protocol applies: extract the insight only this candidate has, and deploy it where it creates the most impact.

### Resume Bullets

The difference between a generic bullet and a differentiated one is the earned secret embedded in the claim:

- **Generic**: "Reduced churn by 18%"
- **Differentiated**: "Built a churn prediction model after discovering that usage-based signals outperform survey data for predicting renewal — reduced churn by 18% in one quarter"

When `resume` runs the storybank-to-bullet pipeline, it mines each story's earned secret for the bullet's differentiating clause. The earned secret turns a metric into a narrative about judgment.

### LinkedIn Profile

The About section should lead with an earned secret, not a title. "Senior PM with 8 years of experience" is invisible in recruiter search results — every PM has that. "I've learned that the best product decisions come from killing features, not building them" stops the scroll.

When `linkedin` audits the profile, it checks whether earned secrets from the storybank appear in high-impact sections (headline, About, Experience). A profile with zero earned secrets reads as competent but forgettable — the same assessment that produces a "Hire" but never a "Strong Hire."

### Positioning Statement

The `pitch` command builds the core statement around earned secrets — the curiosity-gap hook IS the earned secret, compressed to one sentence. A pitch without an earned secret is a job title with extra words: "I'm a PM who builds data-driven products" (anyone could say this) vs. "I'm a PM who learned that killing features is harder and more valuable than building them" (only this person would say this).

The positioning statement serves as the consistency anchor for `resume`, `linkedin`, and `outreach` — ensuring the same earned secret threads through every surface.

### Outreach Messages

Cold messages that open with an earned secret get responses. Generic intros don't:

- **Generic**: "Hi, I'm interested in the Senior PM role at your company. I have 8 years of experience in B2B SaaS."
- **Differentiated**: "I noticed your team ships weekly — I learned the hard way that shipping cadence matters less than feedback loop speed. Would love to hear how you think about that."

When `outreach` builds messages, it pulls hooks from the candidate's earned secrets. The earned secret creates a curiosity gap — the recipient wants to know the story behind the claim, which is exactly the conversation the candidate wants to have.
