# Rolle

Agieren Sie als Experte für technisches Recruiting, professionelles Schreiben von Lebensläufen und ATS-Optimierung (Applicant Tracking System).

# Aufgabe

Lesen Sie meinen aktuellen Lebenslauf in der Datei @index.html. Ich werde Ihnen eine spezifische Stellenbeschreibung zur Verfügung stellen. Ihre Aufgabe ist es, den HTML-Lebenslauf passgenau auf diese Stellenbeschreibung zuzuschneiden und für ATS-Systeme zu optimieren.

**STRIKT:** Der generierte Lebenslauf muss eine exakte Kopie der `@index.html` sein. Verändern Sie ausschließlich den Text innerhalb der HTML-Tags (Inhalt der `<li>`, `<p>`, `<span>`, etc.). Die gesamte HTML-Struktur, alle Meta-Tags, Skripte, Klassen (`class`), IDs, Inline-Styles und Kommentare müssen zu 100 % unverändert übernommen werden.

# Anweisungen

1. **ATS-Optimierung:** Identifizieren Sie die 5 wichtigsten Keywords und Qualifikationen aus der Stellenbeschreibung. Integrieren Sie diese exakt und natürlich in den Text meines Lebenslaufs (vorzugsweise in die `data-lang` Attribute und den Haupttext), um eine hohe ATS-Kompatibilität zu gewährleisten.

2. **STAR-Methode & Quantifizierung:** Überarbeiten Sie die Stichpunkte meiner Berufserfahrung nach der STAR-Methode (Situation, Task, Action, Result). Heben Sie quantifizierbare Erfolge hervor, wo immer möglich.

3. **Tech-Stack Fokus:** Betonen Sie meine Erfahrung mit dem VILT-Stack (Vue, Inertia, Laravel und Tailwind) gezielt, um sie optimal auf die Anforderungen der Stelle abzustimmen.

4. **Lückenanalyse & Transferable Skills:** Führen Sie eine kurze Lückenanalyse durch. Sagen Sie mir explizit, welche Anforderungen noch fehlen, und adressieren Sie diese "Skill Gaps" direkt bei der Überarbeitung, indem Sie relevante, übertragbare Fähigkeiten aus meiner bisherigen Erfahrung betonen.

5. **Erhalt von Code & Funktionalität (STRIKT):** Stellen Sie sicher, dass alle CSS-Klassen, Inline-Styles, JavaScript-Funktionalitäten (wie z. B. Modals, Dark Mode, Animationen, interaktive Buttons) und Meta-Tags aus der @index.html 1:1 übernommen werden. Verändern Sie ausschließlich den Textinhalt (Erfahrungen, Profiltext, Skills). Entfernen oder kürzen Sie keine Skripte oder funktionale HTML-Elemente.

6. **Stil:** Halten Sie den Ton durchgehend professionell, prägnant und handlungsorientiert.

7. **DATEIAUSGABE:** Generieren Sie den vollständigen, aktualisierten HTML-Code. Erstellen Sie eine neue Datei und speichern Sie das Ergebnis unter genau diesem Pfad:
   `/jobs/resumes/[unternehmensname].html`
   (Ersetzen Sie [unternehmensname] durch den tatsächlichen Namen der Firma aus der Stellenbeschreibung. Verwenden Sie nur Kleinbuchstaben und ersetzen Sie Leerzeichen durch Bindestriche).
